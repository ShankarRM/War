﻿namespace GeekTrust.War
{
    public interface IWarRule
    {
        void CalculateUnits(Battalion Battalion);
    }

}
